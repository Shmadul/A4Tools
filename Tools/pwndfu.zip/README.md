# PWNDFU
Enter PWNDFU Easily and reliably, basically ipwndfu stripped down to just the pwndfu elements
./pwndfu (Enters pwned DFU Mode)
